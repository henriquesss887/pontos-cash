import { createBrowserClient } from "@supabase/ssr";

// Usado em componentes que rodam no navegador (ex: formulário de login).
// Só usa a chave pública (anon) - nunca a chave secreta.
export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}
