"use server";

import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";

export async function login(formData: FormData) {
  const email = String(formData.get("email"));
  const senha = String(formData.get("senha"));

  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithPassword({
    email,
    password: senha,
  });

  if (error) {
    return { erro: "E-mail ou senha inválidos." };
  }

  redirect("/dashboard");
}

export async function cadastrar(formData: FormData) {
  const email = String(formData.get("email"));
  const senha = String(formData.get("senha"));
  const nome = String(formData.get("nome"));

  if (senha.length < 8) {
    return { erro: "A senha precisa ter pelo menos 8 caracteres." };
  }

  const supabase = await createClient();
  const { error } = await supabase.auth.signUp({
    email,
    password: senha,
    options: { data: { nome } },
  });

  if (error) {
    return { erro: error.message };
  }

  return {
    sucesso:
      "Cadastro criado! Verifique seu e-mail para confirmar a conta antes de entrar.",
  };
}

export async function logout() {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect("/login");
}

export async function solicitarRecuperacaoSenha(formData: FormData) {
  const email = String(formData.get("email"));
  const supabase = await createClient();

  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: `${process.env.NEXT_PUBLIC_SITE_URL}/redefinir-senha`,
  });

  if (error) {
    return { erro: "Não foi possível enviar o e-mail de recuperação." };
  }

  return { sucesso: "Se o e-mail existir, enviamos um link de recuperação." };
}
