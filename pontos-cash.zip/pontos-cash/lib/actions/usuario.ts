"use server";

import { createClient, getUsuarioLogado } from "@/lib/supabase/server";
import { revalidatePath } from "next/cache";

export async function cadastrarContaBancaria(formData: FormData) {
  const usuario = await getUsuarioLogado();
  if (!usuario) return { erro: "Sessão expirada, faça login novamente." };

  const supabase = await createClient();
  const { error } = await supabase.from("contas_bancarias").insert({
    usuario_id: usuario.id,
    banco: String(formData.get("banco")),
    agencia: String(formData.get("agencia")),
    conta: String(formData.get("conta")),
    tipo: String(formData.get("tipo")),
    titular: String(formData.get("titular")),
    cpf_titular: String(formData.get("cpf_titular")),
  });

  if (error) return { erro: "Não foi possível salvar a conta bancária." };

  revalidatePath("/dashboard");
  return { sucesso: "Conta bancária cadastrada." };
}

export async function enviarVerificacaoIdentidade(formData: FormData) {
  const usuario = await getUsuarioLogado();
  if (!usuario) return { erro: "Sessão expirada, faça login novamente." };

  const supabase = await createClient();
  const { error } = await supabase.from("verificacoes_identidade").upsert(
    {
      usuario_id: usuario.id,
      cpf: String(formData.get("cpf")),
      nome_completo: String(formData.get("nome_completo")),
      status: "pendente",
    },
    { onConflict: "usuario_id" }
  );

  if (error) return { erro: "Não foi possível enviar a verificação." };

  revalidatePath("/dashboard");
  return { sucesso: "Verificação enviada. Aguarde a análise do administrador." };
}

export async function solicitarSaque(formData: FormData) {
  const usuario = await getUsuarioLogado();
  if (!usuario) return { erro: "Sessão expirada, faça login novamente." };

  const supabase = await createClient();

  const pontosSolicitados = Number(formData.get("pontos"));
  const contaBancariaId = String(formData.get("conta_bancaria_id"));

  // Toda a regra de negócio (verificação aprovada, saldo suficiente,
  // débito do saldo) roda dentro da função do banco, de forma atômica.
  const { error } = await supabase.rpc("solicitar_saque", {
    p_conta_bancaria_id: contaBancariaId,
    p_pontos: pontosSolicitados,
  });

  if (error) return { erro: error.message };

  revalidatePath("/dashboard");
  return { sucesso: "Solicitação de saque enviada para análise." };
}
