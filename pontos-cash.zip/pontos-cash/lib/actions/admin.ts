"use server";

import { createClient, getUsuarioLogado } from "@/lib/supabase/server";
import { revalidatePath } from "next/cache";

// Toda função aqui checa a permissão de novo no servidor, além do RLS e das
// funções do banco - permissão nunca depende só do que o frontend esconde.
async function exigirAdmin() {
  const usuario = await getUsuarioLogado();
  if (!usuario || !["admin", "admin_principal"].includes(usuario.role)) {
    throw new Error("Acesso negado.");
  }
  return usuario;
}

export async function creditarPontos(formData: FormData) {
  await exigirAdmin();
  const supabase = await createClient();

  const { error } = await supabase.rpc("admin_creditar_pontos", {
    p_usuario_id: String(formData.get("usuario_id")),
    p_quantidade: Number(formData.get("quantidade")),
    p_motivo: String(formData.get("motivo")),
  });

  if (error) return { erro: error.message };

  revalidatePath("/admin");
  return { sucesso: "Pontos creditados." };
}

export async function atualizarUsuario(formData: FormData) {
  await exigirAdmin();
  const supabase = await createClient();

  const status = formData.get("status") ? String(formData.get("status")) : null;
  const role = formData.get("role") ? String(formData.get("role")) : null;

  const { error } = await supabase.rpc("admin_atualizar_usuario", {
    p_usuario_id: String(formData.get("usuario_id")),
    p_status: status,
    p_role: role,
  });

  if (error) return { erro: error.message };

  revalidatePath("/admin/usuarios");
  return { sucesso: "Usuário atualizado." };
}

export async function atualizarVerificacao(formData: FormData) {
  await exigirAdmin();
  const supabase = await createClient();

  const { error } = await supabase.rpc("admin_atualizar_verificacao", {
    p_verificacao_id: String(formData.get("verificacao_id")),
    p_status: String(formData.get("status")),
    p_observacao: formData.get("observacao")
      ? String(formData.get("observacao"))
      : null,
  });

  if (error) return { erro: error.message };

  revalidatePath("/admin/verificacoes");
  return { sucesso: "Verificação atualizada." };
}

export async function atualizarSaque(formData: FormData) {
  await exigirAdmin();
  const supabase = await createClient();

  const { error } = await supabase.rpc("admin_atualizar_saque", {
    p_saque_id: String(formData.get("saque_id")),
    p_novo_status: String(formData.get("status")),
    p_observacao: formData.get("observacao")
      ? String(formData.get("observacao"))
      : null,
  });

  if (error) return { erro: error.message };

  revalidatePath("/admin/saques");
  return { sucesso: "Saque atualizado." };
}
