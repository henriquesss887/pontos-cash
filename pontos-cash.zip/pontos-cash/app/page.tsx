import { getUsuarioLogado } from "@/lib/supabase/server";
import { redirect } from "next/navigation";

export default async function HomePage() {
  const usuario = await getUsuarioLogado();

  if (usuario) {
    redirect(["admin", "admin_principal"].includes(usuario.role) ? "/admin" : "/dashboard");
  }

  return (
    <div className="container">
      <h1>PontosCash</h1>
      <p style={{ color: "var(--texto-suave)", marginTop: "0.75rem" }}>
        Acumule pontos e troque por dinheiro real, direto na sua conta.
      </p>
      <a href="/login" className="botao">Entrar</a>
      <a href="/cadastro" className="botao botao-secundario" style={{ marginLeft: "0.75rem" }}>
        Criar conta
      </a>
    </div>
  );
}
