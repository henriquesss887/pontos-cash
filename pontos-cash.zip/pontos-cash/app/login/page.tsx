"use client";

import { useState } from "react";
import { login } from "@/lib/actions/auth";

export default function LoginPage() {
  const [erro, setErro] = useState<string | null>(null);
  const [carregando, setCarregando] = useState(false);

  async function acao(formData: FormData) {
    setErro(null);
    setCarregando(true);
    const resultado = await login(formData);
    setCarregando(false);
    if (resultado?.erro) setErro(resultado.erro);
  }

  return (
    <div className="container">
      <h1>Entrar</h1>
      <p style={{ color: "var(--texto-suave)", marginTop: "0.5rem" }}>
        Acesse sua conta para ver seus pontos e solicitar saques.
      </p>

      <form action={acao} className="cartao" style={{ marginTop: "1.5rem" }}>
        <label className="rotulo" htmlFor="email">E-mail</label>
        <input id="email" name="email" type="email" required />

        <label className="rotulo" htmlFor="senha">Senha</label>
        <input id="senha" name="senha" type="password" required />

        {erro && <p className="mensagem-erro">{erro}</p>}

        <button type="submit" disabled={carregando} style={{ width: "100%" }}>
          {carregando ? "Entrando..." : "Entrar"}
        </button>
      </form>

      <p style={{ marginTop: "1.5rem", fontSize: "0.9rem" }}>
        Não tem conta? <a href="/cadastro">Cadastre-se</a>
        <br />
        <a href="/recuperar-senha">Esqueci minha senha</a>
      </p>
    </div>
  );
}
