"use client";

import { useState } from "react";
import { solicitarRecuperacaoSenha } from "@/lib/actions/auth";

export default function RecuperarSenhaPage() {
  const [mensagem, setMensagem] = useState<{ tipo: "erro" | "sucesso"; texto: string } | null>(null);

  async function acao(formData: FormData) {
    setMensagem(null);
    const resultado = await solicitarRecuperacaoSenha(formData);
    if (resultado?.erro) setMensagem({ tipo: "erro", texto: resultado.erro });
    if (resultado?.sucesso) setMensagem({ tipo: "sucesso", texto: resultado.sucesso });
  }

  return (
    <div className="container">
      <h1>Recuperar senha</h1>
      <p style={{ color: "var(--texto-suave)", marginTop: "0.5rem" }}>
        Informe seu e-mail para receber um link de redefinição de senha.
      </p>

      <form action={acao} className="cartao" style={{ marginTop: "1.5rem" }}>
        <label className="rotulo" htmlFor="email">E-mail</label>
        <input id="email" name="email" type="email" required />

        {mensagem && (
          <p className={mensagem.tipo === "erro" ? "mensagem-erro" : "mensagem-sucesso"}>
            {mensagem.texto}
          </p>
        )}

        <button type="submit" style={{ width: "100%" }}>Enviar link</button>
      </form>
    </div>
  );
}
