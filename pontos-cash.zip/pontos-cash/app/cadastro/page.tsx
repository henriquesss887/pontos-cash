"use client";

import { useState } from "react";
import { cadastrar } from "@/lib/actions/auth";

export default function CadastroPage() {
  const [mensagem, setMensagem] = useState<{ tipo: "erro" | "sucesso"; texto: string } | null>(null);
  const [carregando, setCarregando] = useState(false);

  async function acao(formData: FormData) {
    setMensagem(null);
    setCarregando(true);
    const resultado = await cadastrar(formData);
    setCarregando(false);
    if (resultado?.erro) setMensagem({ tipo: "erro", texto: resultado.erro });
    if (resultado?.sucesso) setMensagem({ tipo: "sucesso", texto: resultado.sucesso });
  }

  return (
    <div className="container">
      <h1>Criar conta</h1>

      <form action={acao} className="cartao" style={{ marginTop: "1.5rem" }}>
        <label className="rotulo" htmlFor="nome">Nome completo</label>
        <input id="nome" name="nome" type="text" required />

        <label className="rotulo" htmlFor="email">E-mail</label>
        <input id="email" name="email" type="email" required />

        <label className="rotulo" htmlFor="senha">Senha (mínimo 8 caracteres)</label>
        <input id="senha" name="senha" type="password" minLength={8} required />

        {mensagem && (
          <p className={mensagem.tipo === "erro" ? "mensagem-erro" : "mensagem-sucesso"}>
            {mensagem.texto}
          </p>
        )}

        <button type="submit" disabled={carregando} style={{ width: "100%" }}>
          {carregando ? "Criando..." : "Criar conta"}
        </button>
      </form>

      <p style={{ marginTop: "1.5rem", fontSize: "0.9rem" }}>
        Já tem conta? <a href="/login">Entrar</a>
      </p>
    </div>
  );
}
