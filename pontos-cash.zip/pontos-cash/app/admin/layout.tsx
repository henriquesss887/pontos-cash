import { getUsuarioLogado } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { logout } from "@/lib/actions/auth";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const usuario = await getUsuarioLogado();

  // Segunda checagem de permissão no servidor (além do middleware e do RLS)
  if (!usuario || !["admin", "admin_principal"].includes(usuario.role)) {
    redirect("/dashboard");
  }

  return (
    <div>
      <nav className="admin-nav">
        <a href="/admin">Dashboard</a>
        <a href="/admin/usuarios">Usuários</a>
        <a href="/admin/verificacoes">Verificações</a>
        <a href="/admin/saques">Saques</a>
        <a href="/admin/pontos">Creditar pontos</a>
        <form action={logout} style={{ marginLeft: "auto" }}>
          <button type="submit" style={{ marginTop: 0, background: "transparent", color: "var(--texto-suave)", padding: 0 }}>
            Sair
          </button>
        </form>
      </nav>
      <div className="container-largo">{children}</div>
    </div>
  );
}
