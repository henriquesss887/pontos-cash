import { createClient, getUsuarioLogado } from "@/lib/supabase/server";
import { atualizarUsuario } from "@/lib/actions/admin";
import AutoRefresh from "@/components/AutoRefresh";

export default async function AdminUsuariosPage() {
  const supabase = await createClient();
  const admin = await getUsuarioLogado();

  const { data: usuarios } = await supabase
    .from("profiles")
    .select("*")
    .order("criado_em", { ascending: false });

  return (
    <div style={{ padding: "2rem 0" }}>
      <AutoRefresh tabelas={["profiles"]} />
      <h1>Usuários</h1>

      <table style={{ marginTop: "1.5rem" }}>
        <thead>
          <tr>
            <th>Nome</th><th>E-mail</th><th>Papel</th><th>Status</th><th>Saldo</th><th>Ações</th>
          </tr>
        </thead>
        <tbody>
          {(usuarios ?? []).map((u) => (
            <tr key={u.id}>
              <td>{u.nome}</td>
              <td>{u.email}</td>
              <td>{u.role}</td>
              <td><span className={`tag tag-${u.status}`}>{u.status}</span></td>
              <td>{u.saldo_pontos}</td>
              <td style={{ display: "flex", gap: "0.5rem" }}>
                <form action={atualizarUsuario}>
                  <input type="hidden" name="usuario_id" value={u.id} />
                  <input type="hidden" name="status" value={u.status === "ativo" ? "bloqueado" : "ativo"} />
                  <button type="submit" className="botao-secundario" style={{ marginTop: 0, padding: "0.35rem 0.7rem", fontSize: "0.8rem" }}>
                    {u.status === "ativo" ? "Bloquear" : "Desbloquear"}
                  </button>
                </form>

                {admin?.role === "admin_principal" && u.id !== admin.id && (
                  <form action={atualizarUsuario}>
                    <input type="hidden" name="usuario_id" value={u.id} />
                    <input type="hidden" name="role" value={u.role === "admin" ? "usuario" : "admin"} />
                    <button type="submit" className="botao-secundario" style={{ marginTop: 0, padding: "0.35rem 0.7rem", fontSize: "0.8rem" }}>
                      {u.role === "admin" ? "Remover admin" : "Tornar admin"}
                    </button>
                  </form>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
