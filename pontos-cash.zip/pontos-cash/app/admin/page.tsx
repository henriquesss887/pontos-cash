import { createClient } from "@/lib/supabase/server";

export default async function AdminDashboardPage() {
  const supabase = await createClient();

  const [{ count: totalUsuarios }, { count: verificacoesPendentes }, { count: saquesPendentes }, { data: saques }] =
    await Promise.all([
      supabase.from("profiles").select("*", { count: "exact", head: true }),
      supabase
        .from("verificacoes_identidade")
        .select("*", { count: "exact", head: true })
        .eq("status", "pendente"),
      supabase
        .from("solicitacoes_saque")
        .select("*", { count: "exact", head: true })
        .eq("status", "pendente"),
      supabase.from("solicitacoes_saque").select("valor_reais, status"),
    ]);

  const totalPago = (saques ?? [])
    .filter((s) => s.status === "pago")
    .reduce((soma, s) => soma + Number(s.valor_reais), 0);

  const cards = [
    { titulo: "Total de usuários", valor: totalUsuarios ?? 0 },
    { titulo: "Verificações pendentes", valor: verificacoesPendentes ?? 0, alerta: (verificacoesPendentes ?? 0) > 0 },
    { titulo: "Saques pendentes", valor: saquesPendentes ?? 0, alerta: (saquesPendentes ?? 0) > 0 },
    { titulo: "Total já pago", valor: `R$ ${totalPago.toFixed(2)}` },
  ];

  return (
    <div style={{ padding: "2rem 0" }}>
      <h1>Dashboard</h1>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: "1rem", marginTop: "1.5rem" }}>
        {cards.map((c) => (
          <div key={c.titulo} className="cartao">
            <p style={{ color: "var(--texto-suave)", fontSize: "0.85rem", margin: 0 }}>{c.titulo}</p>
            <p style={{ fontSize: "1.8rem", fontFamily: "Fraunces, serif", margin: "0.3rem 0 0", color: c.alerta ? "var(--erro)" : "var(--verde-profundo)" }}>
              {c.valor}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}
