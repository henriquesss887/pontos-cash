import { createClient } from "@/lib/supabase/server";
import { creditarPontos } from "@/lib/actions/admin";
import AutoRefresh from "@/components/AutoRefresh";

export default async function AdminPontosPage() {
  const supabase = await createClient();
  const { data: usuarios } = await supabase
    .from("profiles")
    .select("id, nome, email, saldo_pontos")
    .eq("role", "usuario")
    .order("nome");

  return (
    <div style={{ padding: "2rem 0", maxWidth: "480px" }}>
      <AutoRefresh tabelas={["pontos_ledger"]} />
      <h1>Creditar pontos</h1>

      <form action={creditarPontos} className="cartao" style={{ marginTop: "1.5rem" }}>
        <label className="rotulo" htmlFor="usuario_id">Usuário</label>
        <select id="usuario_id" name="usuario_id" required>
          {(usuarios ?? []).map((u) => (
            <option key={u.id} value={u.id}>
              {u.nome} ({u.email}) — saldo atual: {u.saldo_pontos}
            </option>
          ))}
        </select>

        <label className="rotulo" htmlFor="quantidade">Quantidade de pontos</label>
        <input id="quantidade" name="quantidade" type="number" min={1} required />

        <label className="rotulo" htmlFor="motivo">Motivo</label>
        <input id="motivo" name="motivo" required placeholder="Ex: bônus de indicação" />

        <button type="submit">Creditar pontos</button>
      </form>
    </div>
  );
}
