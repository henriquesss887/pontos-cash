import { createClient } from "@/lib/supabase/server";
import { atualizarVerificacao } from "@/lib/actions/admin";
import AutoRefresh from "@/components/AutoRefresh";

export default async function AdminVerificacoesPage() {
  const supabase = await createClient();

  const { data: verificacoes } = await supabase
    .from("verificacoes_identidade")
    .select("*, profiles!verificacoes_identidade_usuario_id_fkey(nome, email)")
    .order("criado_em", { ascending: false });

  return (
    <div style={{ padding: "2rem 0" }}>
      <AutoRefresh tabelas={["verificacoes_identidade"]} />
      <h1>Verificações de identidade</h1>

      <table style={{ marginTop: "1.5rem" }}>
        <thead>
          <tr><th>Usuário</th><th>Nome completo</th><th>CPF</th><th>Status</th><th>Ações</th></tr>
        </thead>
        <tbody>
          {(verificacoes ?? []).map((v: any) => (
            <tr key={v.id}>
              <td>{v.profiles?.nome}<br /><span style={{ color: "var(--texto-suave)", fontSize: "0.8rem" }}>{v.profiles?.email}</span></td>
              <td>{v.nome_completo}</td>
              <td>{v.cpf}</td>
              <td><span className={`tag tag-${v.status}`}>{v.status}</span></td>
              <td style={{ display: "flex", gap: "0.5rem" }}>
                {v.status !== "aprovado" && (
                  <form action={atualizarVerificacao}>
                    <input type="hidden" name="verificacao_id" value={v.id} />
                    <input type="hidden" name="status" value="aprovado" />
                    <button type="submit" style={{ marginTop: 0, padding: "0.35rem 0.7rem", fontSize: "0.8rem" }}>
                      Aprovar
                    </button>
                  </form>
                )}
                {v.status !== "rejeitado" && (
                  <form action={atualizarVerificacao}>
                    <input type="hidden" name="verificacao_id" value={v.id} />
                    <input type="hidden" name="status" value="rejeitado" />
                    <button type="submit" className="botao-secundario" style={{ marginTop: 0, padding: "0.35rem 0.7rem", fontSize: "0.8rem" }}>
                      Rejeitar
                    </button>
                  </form>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
