import { createClient } from "@/lib/supabase/server";
import { atualizarSaque } from "@/lib/actions/admin";
import AutoRefresh from "@/components/AutoRefresh";

export default async function AdminSaquesPage() {
  const supabase = await createClient();

  const { data: saques } = await supabase
    .from("solicitacoes_saque")
    .select(`
      *,
      profiles!solicitacoes_saque_usuario_id_fkey(nome, email),
      contas_bancarias(banco, agencia, conta, tipo, titular, cpf_titular)
    `)
    .order("criado_em", { ascending: false });

  return (
    <div style={{ padding: "2rem 0" }}>
      <AutoRefresh tabelas={["solicitacoes_saque"]} />
      <h1>Solicitações de saque</h1>

      <table style={{ marginTop: "1.5rem" }}>
        <thead>
          <tr><th>Usuário</th><th>Dados bancários</th><th>Valor</th><th>Status</th><th>Ações</th></tr>
        </thead>
        <tbody>
          {(saques ?? []).map((s: any) => (
            <tr key={s.id}>
              <td>{s.profiles?.nome}<br /><span style={{ color: "var(--texto-suave)", fontSize: "0.8rem" }}>{s.profiles?.email}</span></td>
              <td style={{ fontSize: "0.85rem" }}>
                {s.contas_bancarias?.banco} — Ag. {s.contas_bancarias?.agencia} / Conta {s.contas_bancarias?.conta}
                <br />Titular: {s.contas_bancarias?.titular} (CPF {s.contas_bancarias?.cpf_titular})
              </td>
              <td>R$ {Number(s.valor_reais).toFixed(2)}<br /><span style={{ fontSize: "0.8rem", color: "var(--texto-suave)" }}>{s.pontos_debitados} pts</span></td>
              <td><span className={`tag tag-${s.status}`}>{s.status}</span></td>
              <td style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap" }}>
                {s.status === "pendente" && (
                  <form action={atualizarSaque}>
                    <input type="hidden" name="saque_id" value={s.id} />
                    <input type="hidden" name="status" value="aprovado" />
                    <button type="submit" style={{ marginTop: 0, padding: "0.35rem 0.7rem", fontSize: "0.8rem" }}>
                      Aprovar
                    </button>
                  </form>
                )}
                {s.status === "aprovado" && (
                  <form action={atualizarSaque}>
                    <input type="hidden" name="saque_id" value={s.id} />
                    <input type="hidden" name="status" value="pago" />
                    <button type="submit" style={{ marginTop: 0, padding: "0.35rem 0.7rem", fontSize: "0.8rem" }}>
                      Marcar como pago
                    </button>
                  </form>
                )}
                {(s.status === "pendente" || s.status === "aprovado") && (
                  <form action={atualizarSaque}>
                    <input type="hidden" name="saque_id" value={s.id} />
                    <input type="hidden" name="status" value="rejeitado" />
                    <button type="submit" className="botao-secundario" style={{ marginTop: 0, padding: "0.35rem 0.7rem", fontSize: "0.8rem" }}>
                      Rejeitar (estorna pontos)
                    </button>
                  </form>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
