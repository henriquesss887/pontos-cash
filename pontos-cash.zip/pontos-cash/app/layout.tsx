import "./globals.css";

export const metadata = {
  title: "PontosCash",
  description: "Troque seus pontos acumulados por dinheiro real",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pt-BR">
      <body>{children}</body>
    </html>
  );
}
