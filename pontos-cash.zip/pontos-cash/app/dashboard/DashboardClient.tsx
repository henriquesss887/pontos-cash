"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import {
  cadastrarContaBancaria,
  enviarVerificacaoIdentidade,
  solicitarSaque,
} from "@/lib/actions/usuario";
import { logout } from "@/lib/actions/auth";

type Props = {
  usuarioInicial: any;
  verificacaoInicial: any;
  contasIniciais: any[];
  saquesIniciais: any[];
  historicoInicial: any[];
};

export default function DashboardClient({
  usuarioInicial,
  verificacaoInicial,
  contasIniciais,
  saquesIniciais,
  historicoInicial,
}: Props) {
  const [usuario, setUsuario] = useState(usuarioInicial);
  const [verificacao, setVerificacao] = useState(verificacaoInicial);
  const [contas, setContas] = useState(contasIniciais);
  const [saques, setSaques] = useState(saquesIniciais);
  const [historico, setHistorico] = useState(historicoInicial);
  const [mensagem, setMensagem] = useState<{ tipo: "erro" | "sucesso"; texto: string } | null>(null);

  // Sincronização em tempo real: qualquer mudança feita pelo admin
  // (aprovar verificação, creditar pontos, atualizar saque) aparece aqui
  // automaticamente, sem precisar recarregar a página.
  useEffect(() => {
    const supabase = createClient();

    const canal = supabase
      .channel(`dashboard-${usuarioInicial.id}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "profiles", filter: `id=eq.${usuarioInicial.id}` },
        (payload) => setUsuario((atual: any) => ({ ...atual, ...payload.new }))
      )
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "verificacoes_identidade",
          filter: `usuario_id=eq.${usuarioInicial.id}`,
        },
        (payload) => setVerificacao(payload.new)
      )
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "solicitacoes_saque",
          filter: `usuario_id=eq.${usuarioInicial.id}`,
        },
        (payload) => {
          setSaques((atual: any[]) => {
            if (payload.eventType === "INSERT") return [payload.new, ...atual];
            return atual.map((s) => (s.id === payload.new.id ? payload.new : s));
          });
        }
      )
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "pontos_ledger",
          filter: `usuario_id=eq.${usuarioInicial.id}`,
        },
        (payload) => setHistorico((atual: any[]) => [payload.new, ...atual].slice(0, 20))
      )
      .subscribe();

    return () => {
      supabase.removeChannel(canal);
    };
  }, [usuarioInicial.id]);

  async function acaoComMensagem(fn: (fd: FormData) => Promise<any>, formData: FormData, formEl?: HTMLFormElement) {
    setMensagem(null);
    const resultado = await fn(formData);
    if (resultado?.erro) setMensagem({ tipo: "erro", texto: resultado.erro });
    if (resultado?.sucesso) {
      setMensagem({ tipo: "sucesso", texto: resultado.sucesso });
      formEl?.reset();
    }
  }

  const identidadeAprovada = verificacao?.status === "aprovado";

  return (
    <div className="container">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h1>Olá, {usuario.nome?.split(" ")[0]}</h1>
        <form action={logout}>
          <button type="submit" className="botao-secundario" style={{ marginTop: 0, padding: "0.4rem 0.9rem", fontSize: "0.85rem" }}>
            Sair
          </button>
        </form>
      </div>

      <div className="cartao" style={{ marginTop: "1.5rem" }}>
        <p style={{ color: "var(--texto-suave)", margin: 0 }}>Seu saldo</p>
        <p className="saldo-destaque">{usuario.saldo_pontos} pontos</p>
        <p style={{ color: "var(--texto-suave)", fontSize: "0.9rem" }}>
          ≈ R$ {(usuario.saldo_pontos / 100).toFixed(2)}
        </p>
      </div>

      {mensagem && (
        <p className={mensagem.tipo === "erro" ? "mensagem-erro" : "mensagem-sucesso"}>{mensagem.texto}</p>
      )}

      {/* Verificação de identidade */}
      <div className="cartao" style={{ marginTop: "1.5rem" }}>
        <h3>Verificação de identidade</h3>
        <p style={{ fontSize: "0.9rem", marginTop: "0.5rem" }}>
          Status: <span className={`tag tag-${verificacao?.status ?? "pendente"}`}>{verificacao?.status ?? "não enviada"}</span>
        </p>
        {!identidadeAprovada && (
          <form
            action={(fd) => acaoComMensagem(enviarVerificacaoIdentidade, fd)}
          >
            <label className="rotulo" htmlFor="nome_completo">Nome completo</label>
            <input id="nome_completo" name="nome_completo" required defaultValue={verificacao?.nome_completo ?? ""} />
            <label className="rotulo" htmlFor="cpf">CPF</label>
            <input id="cpf" name="cpf" required defaultValue={verificacao?.cpf ?? ""} />
            <button type="submit">Enviar para verificação</button>
          </form>
        )}
      </div>

      {/* Contas bancárias */}
      <div className="cartao" style={{ marginTop: "1.5rem" }}>
        <h3>Conta bancária</h3>
        {contas.map((c) => (
          <p key={c.id} style={{ fontSize: "0.9rem" }}>
            {c.banco} — Ag. {c.agencia} / Conta {c.conta} ({c.tipo})
          </p>
        ))}
        <form
          action={async (fd) => {
            await acaoComMensagem(cadastrarContaBancaria, fd);
          }}
        >
          <label className="rotulo" htmlFor="banco">Banco</label>
          <input id="banco" name="banco" required />
          <label className="rotulo" htmlFor="agencia">Agência</label>
          <input id="agencia" name="agencia" required />
          <label className="rotulo" htmlFor="conta">Conta</label>
          <input id="conta" name="conta" required />
          <label className="rotulo" htmlFor="tipo">Tipo</label>
          <select id="tipo" name="tipo" required>
            <option value="corrente">Conta corrente</option>
            <option value="poupanca">Conta poupança</option>
          </select>
          <label className="rotulo" htmlFor="titular">Nome do titular</label>
          <input id="titular" name="titular" required />
          <label className="rotulo" htmlFor="cpf_titular">CPF do titular</label>
          <input id="cpf_titular" name="cpf_titular" required />
          <button type="submit">Adicionar conta bancária</button>
        </form>
      </div>

      {/* Solicitar saque */}
      <div className="cartao" style={{ marginTop: "1.5rem" }}>
        <h3>Solicitar saque</h3>
        {!identidadeAprovada && (
          <p style={{ fontSize: "0.9rem", color: "var(--texto-suave)" }}>
            Sua identidade precisa ser verificada e aprovada antes de solicitar saque.
          </p>
        )}
        {identidadeAprovada && contas.length === 0 && (
          <p style={{ fontSize: "0.9rem", color: "var(--texto-suave)" }}>
            Cadastre uma conta bancária antes de solicitar saque.
          </p>
        )}
        {identidadeAprovada && contas.length > 0 && (
          <form action={(fd) => acaoComMensagem(solicitarSaque, fd)}>
            <label className="rotulo" htmlFor="conta_bancaria_id">Conta bancária</label>
            <select id="conta_bancaria_id" name="conta_bancaria_id" required>
              {contas.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.banco} — Ag. {c.agencia} / Conta {c.conta}
                </option>
              ))}
            </select>
            <label className="rotulo" htmlFor="pontos">Quantidade de pontos</label>
            <input id="pontos" name="pontos" type="number" min={1} max={usuario.saldo_pontos} required />
            <button type="submit">Solicitar saque</button>
          </form>
        )}

        {saques.length > 0 && (
          <table style={{ marginTop: "1.5rem" }}>
            <thead>
              <tr><th>Data</th><th>Pontos</th><th>Valor</th><th>Status</th></tr>
            </thead>
            <tbody>
              {saques.map((s) => (
                <tr key={s.id}>
                  <td>{new Date(s.criado_em).toLocaleDateString("pt-BR")}</td>
                  <td>{s.pontos_debitados}</td>
                  <td>R$ {Number(s.valor_reais).toFixed(2)}</td>
                  <td><span className={`tag tag-${s.status}`}>{s.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Histórico de pontos */}
      <div className="cartao" style={{ marginTop: "1.5rem", marginBottom: "2rem" }}>
        <h3>Histórico de pontos</h3>
        <table style={{ marginTop: "0.75rem" }}>
          <tbody>
            {historico.map((h) => (
              <tr key={h.id}>
                <td>{new Date(h.criado_em).toLocaleDateString("pt-BR")}</td>
                <td>{h.motivo}</td>
                <td style={{ color: h.tipo === "credito" ? "var(--verde-profundo)" : "var(--erro)" }}>
                  {h.tipo === "credito" ? "+" : "-"}{h.quantidade}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
