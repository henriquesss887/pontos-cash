import { getUsuarioLogado, createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import DashboardClient from "./DashboardClient";

export default async function DashboardPage() {
  const usuario = await getUsuarioLogado();
  if (!usuario) redirect("/login");

  const supabase = await createClient();

  const [{ data: verificacao }, { data: contas }, { data: saques }, { data: historico }] =
    await Promise.all([
      supabase
        .from("verificacoes_identidade")
        .select("*")
        .eq("usuario_id", usuario.id)
        .maybeSingle(),
      supabase
        .from("contas_bancarias")
        .select("*")
        .eq("usuario_id", usuario.id)
        .order("criado_em", { ascending: false }),
      supabase
        .from("solicitacoes_saque")
        .select("*")
        .eq("usuario_id", usuario.id)
        .order("criado_em", { ascending: false }),
      supabase
        .from("pontos_ledger")
        .select("*")
        .eq("usuario_id", usuario.id)
        .order("criado_em", { ascending: false })
        .limit(20),
    ]);

  return (
    <DashboardClient
      usuarioInicial={usuario}
      verificacaoInicial={verificacao}
      contasIniciais={contas ?? []}
      saquesIniciais={saques ?? []}
      historicoInicial={historico ?? []}
    />
  );
}
