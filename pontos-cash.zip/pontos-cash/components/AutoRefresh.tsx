"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

// Escuta mudanças em uma ou mais tabelas e recarrega os dados da página
// (sem recarregar o navegador) sempre que algo muda no banco.
export default function AutoRefresh({ tabelas }: { tabelas: string[] }) {
  const router = useRouter();

  useEffect(() => {
    const supabase = createClient();
    const canal = supabase.channel(`auto-refresh-${tabelas.join("-")}`);

    tabelas.forEach((tabela) => {
      canal.on(
        "postgres_changes",
        { event: "*", schema: "public", table: tabela },
        () => router.refresh()
      );
    });

    canal.subscribe();

    return () => {
      supabase.removeChannel(canal);
    };
  }, [tabelas, router]);

  return null;
}
