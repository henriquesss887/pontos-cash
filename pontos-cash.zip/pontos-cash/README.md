# PontosCash

Sistema de pontos acumulados trocados por dinheiro real. Banco de dados real
(PostgreSQL via Supabase), autenticação real, sincronização em tempo real,
painel administrativo com permissões aplicadas no backend.

## Como está organizado

```
app/                 -> páginas (rotas) do site
  login, cadastro, recuperar-senha  -> públicas
  dashboard/                        -> área do usuário (protegida)
  admin/                            -> painel administrativo (protegido)
lib/
  supabase/           -> conexão com o banco (cliente e servidor)
  actions/            -> toda a lógica de negócio (Server Actions)
components/           -> componentes reutilizáveis
supabase/schema.sql   -> banco de dados completo (rodar no Supabase)
```

---

## Passo 1 — Criar o projeto no Supabase (gratuito)

1. Acesse https://supabase.com e crie uma conta.
2. Clique em "New Project". Escolha um nome e uma senha forte para o banco
   (guarde essa senha).
3. Espere o projeto ser criado (~2 minutos).
4. No menu lateral, vá em **SQL Editor** → **New query**.
5. Abra o arquivo `supabase/schema.sql` deste projeto, copie todo o
   conteúdo, cole no editor e clique em **Run**. Isso cria todas as
   tabelas, permissões e funções do sistema de uma vez.
6. Vá em **Authentication → Providers** e confirme que "Email" está ativado.
7. Vá em **Authentication → URL Configuration** e, mais tarde (depois do
   deploy), adicione a URL do seu site em produção.
8. Vá em **Project Settings → API**. Você vai precisar de dois valores:
   - **Project URL**
   - **anon public key**
   (e, para uso administrativo futuro, a **service_role key** — nunca
   compartilhe essa chave nem a coloque no frontend).

## Passo 2 — Configurar o projeto localmente

1. Copie `.env.example` para `.env.local`.
2. Preencha com os valores do Passo 1:
   ```
   NEXT_PUBLIC_SUPABASE_URL=...
   NEXT_PUBLIC_SUPABASE_ANON_KEY=...
   ```
3. Instale as dependências e rode localmente:
   ```
   npm install
   npm run dev
   ```
4. Acesse http://localhost:3000

## Passo 3 — Criar sua conta de Administrador Principal

Por segurança, todo cadastro novo entra como "usuário" comum — ninguém vira
admin sozinho. Para criar o primeiro administrador principal:

1. Cadastre-se normalmente pela tela `/cadastro` com o e-mail que você vai
   usar como administrador.
2. Confirme o e-mail (o Supabase envia automaticamente).
3. No Supabase, vá em **SQL Editor** e rode (trocando pelo seu e-mail):
   ```sql
   update public.profiles
   set role = 'admin_principal'
   where email = 'seu-email@exemplo.com';
   ```
4. Faça login novamente — você já entra direto no painel `/admin`.

## Passo 4 — Publicar na internet (Vercel, gratuito para começar)

1. Suba este projeto para um repositório no GitHub.
2. Acesse https://vercel.com, crie uma conta e clique em **Add New → Project**.
3. Selecione o repositório do GitHub.
4. Em **Environment Variables**, adicione as mesmas variáveis do
   `.env.local`.
5. Clique em **Deploy**. Em ~1 minuto seu site estará no ar em um link
   como `seu-projeto.vercel.app`.
6. Volte ao Supabase → **Authentication → URL Configuration** e adicione
   essa URL como "Site URL" e em "Redirect URLs" (necessário para
   recuperação de senha funcionar em produção).

## Passo 5 — Domínio próprio e HTTPS

1. Compre um domínio (Registro.br para `.com.br`, ou Namecheap/GoDaddy
   para outros).
2. No painel da Vercel, vá em **Settings → Domains** do seu projeto e
   adicione o domínio.
3. A Vercel mostra os registros DNS que você precisa cadastrar no painel
   onde comprou o domínio. Depois de propagar (minutos a poucas horas),
   o HTTPS é configurado automaticamente e de graça.

---

## Backup do banco de dados

- **Automático**: nos planos pagos do Supabase, backups diários ficam
  disponíveis em **Database → Backups**.
- **Manual (plano gratuito)**: em **Database → Backups** também é
  possível gerar um backup sob demanda, ou usar `pg_dump` apontando para
  a connection string do seu projeto (disponível em
  **Project Settings → Database**). Recomendo fazer isso periodicamente
  enquanto estiver no plano gratuito.

## Exportar dados (CSV)

O Supabase permite exportar o resultado de qualquer tabela ou consulta
como CSV diretamente pelo **Table Editor** (botão "Export" no canto
superior). Para automatizar isso dentro do próprio painel admin do
sistema, é um próximo passo que podemos construir.

## Quando isso pode ter custo

- **Supabase**: gratuito até certos limites (500MB de banco, 50k usuários
  autenticados/mês). Acima disso, plano Pro a partir de US$25/mês.
- **Vercel**: gratuito para projetos pessoais/baixo tráfego. Uso comercial
  intenso pode exigir o plano Pro (US$20/mês).
- **Domínio**: geralmente R$40–60/ano.
- Pagamento real (PIX automático) não está incluído nesta versão — hoje o
  admin aprova e paga manualmente. Se no futuro quiser automatizar, será
  necessário integrar um gateway de pagamento (Asaas, Pagar.me ou Efí),
  que cobra uma taxa por transferência.

## O que ainda vale desenvolver a seguir

- Upload do documento de identidade (Supabase Storage) na tela de
  verificação — hoje só o CPF e nome são enviados.
- Exportação de relatórios (CSV) direto do painel admin.
- E-mails automáticos de notificação (ex: "seu saque foi pago").
- Ajustar a regra de conversão de pontos → reais (hoje fixa em
  100 pontos = R$ 1,00) para onde fizer sentido no seu negócio.
