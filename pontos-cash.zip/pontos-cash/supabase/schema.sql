-- =========================================================
-- SCHEMA COMPLETO - Sistema de Pontos trocados por dinheiro
-- Rodar este arquivo inteiro no SQL Editor do Supabase
-- =========================================================

-- Extensão usada para gerar UUIDs
create extension if not exists "pgcrypto";

-- ---------------------------------------------------------
-- 1. PAPÉIS (ROLES)
-- ---------------------------------------------------------
create type user_role as enum ('admin_principal', 'admin', 'usuario');
create type status_conta as enum ('ativo', 'bloqueado');
create type status_verificacao as enum ('pendente', 'aprovado', 'rejeitado');
create type status_saque as enum ('pendente', 'aprovado', 'pago', 'rejeitado');
create type tipo_conta_bancaria as enum ('corrente', 'poupanca');

-- ---------------------------------------------------------
-- 2. PROFILES - dados do usuário, ligados ao login do Supabase Auth
-- ---------------------------------------------------------
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  nome text not null,
  email text not null,
  role user_role not null default 'usuario',
  status status_conta not null default 'ativo',
  saldo_pontos integer not null default 0,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);

create index idx_profiles_role on public.profiles(role);
create index idx_profiles_status on public.profiles(status);

-- ---------------------------------------------------------
-- 3. VERIFICAÇÃO DE IDENTIDADE - obrigatória antes de liberar saque
-- ---------------------------------------------------------
create table public.verificacoes_identidade (
  id uuid primary key default gen_random_uuid(),
  usuario_id uuid not null references public.profiles(id) on delete cascade,
  cpf text not null,
  nome_completo text not null,
  documento_url text, -- link do arquivo enviado (Supabase Storage)
  status status_verificacao not null default 'pendente',
  observacao_admin text,
  revisado_por uuid references public.profiles(id),
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now(),
  unique(usuario_id)
);

create index idx_verificacoes_status on public.verificacoes_identidade(status);

-- ---------------------------------------------------------
-- 4. CONTAS BANCÁRIAS - dados sensíveis do usuário
-- ---------------------------------------------------------
create table public.contas_bancarias (
  id uuid primary key default gen_random_uuid(),
  usuario_id uuid not null references public.profiles(id) on delete cascade,
  banco text not null,
  agencia text not null,
  conta text not null,
  tipo tipo_conta_bancaria not null,
  titular text not null,
  cpf_titular text not null,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);

create index idx_contas_bancarias_usuario on public.contas_bancarias(usuario_id);

-- ---------------------------------------------------------
-- 5. LIVRO-RAZÃO DE PONTOS - histórico completo, nunca só um saldo
-- ---------------------------------------------------------
create type tipo_lancamento as enum ('credito', 'debito');

create table public.pontos_ledger (
  id uuid primary key default gen_random_uuid(),
  usuario_id uuid not null references public.profiles(id) on delete cascade,
  tipo tipo_lancamento not null,
  quantidade integer not null check (quantidade > 0),
  motivo text not null,
  criado_por uuid not null references public.profiles(id),
  criado_em timestamptz not null default now()
);

create index idx_pontos_ledger_usuario on public.pontos_ledger(usuario_id);
create index idx_pontos_ledger_criado_em on public.pontos_ledger(criado_em desc);

-- ---------------------------------------------------------
-- 6. SOLICITAÇÕES DE SAQUE
-- ---------------------------------------------------------
create table public.solicitacoes_saque (
  id uuid primary key default gen_random_uuid(),
  usuario_id uuid not null references public.profiles(id) on delete cascade,
  conta_bancaria_id uuid not null references public.contas_bancarias(id),
  pontos_debitados integer not null check (pontos_debitados > 0),
  valor_reais numeric(10,2) not null check (valor_reais > 0),
  status status_saque not null default 'pendente',
  observacao_admin text,
  revisado_por uuid references public.profiles(id),
  pago_em timestamptz,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);

create index idx_saques_status on public.solicitacoes_saque(status);
create index idx_saques_usuario on public.solicitacoes_saque(usuario_id);

-- ---------------------------------------------------------
-- 7. AUDIT LOG - rastreabilidade das ações administrativas
-- ---------------------------------------------------------
create table public.audit_log (
  id uuid primary key default gen_random_uuid(),
  ator_id uuid not null references public.profiles(id),
  acao text not null,
  entidade text not null,
  entidade_id uuid,
  detalhes jsonb,
  criado_em timestamptz not null default now()
);

create index idx_audit_log_ator on public.audit_log(ator_id);
create index idx_audit_log_criado_em on public.audit_log(criado_em desc);

-- =========================================================
-- FUNÇÕES AUXILIARES
-- =========================================================

-- Retorna o papel do usuário logado (usada nas políticas abaixo)
create or replace function public.meu_papel()
returns user_role
language sql
security definer
stable
as $$
  select role from public.profiles where id = auth.uid();
$$;

-- Cria automaticamente um profile quando um novo usuário se cadastra
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
as $$
begin
  insert into public.profiles (id, nome, email)
  values (new.id, coalesce(new.raw_user_meta_data->>'nome', ''), new.email);
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- =========================================================
-- ROW LEVEL SECURITY (RLS) - permissões aplicadas no banco,
-- não apenas escondendo botões no frontend
-- =========================================================

alter table public.profiles enable row level security;
alter table public.verificacoes_identidade enable row level security;
alter table public.contas_bancarias enable row level security;
alter table public.pontos_ledger enable row level security;
alter table public.solicitacoes_saque enable row level security;
alter table public.audit_log enable row level security;

-- PROFILES
create policy "usuario ve o proprio perfil" on public.profiles
  for select using (id = auth.uid());

create policy "admin ve todos os perfis" on public.profiles
  for select using (public.meu_papel() in ('admin', 'admin_principal'));

create policy "usuario atualiza o proprio perfil (dados basicos)" on public.profiles
  for update using (id = auth.uid());

create policy "admin atualiza qualquer perfil" on public.profiles
  for update using (public.meu_papel() in ('admin', 'admin_principal'));

-- VERIFICAÇÕES DE IDENTIDADE
create policy "usuario ve a propria verificacao" on public.verificacoes_identidade
  for select using (usuario_id = auth.uid());

create policy "usuario cria a propria verificacao" on public.verificacoes_identidade
  for insert with check (usuario_id = auth.uid());

create policy "admin ve todas as verificacoes" on public.verificacoes_identidade
  for select using (public.meu_papel() in ('admin', 'admin_principal'));

create policy "admin atualiza verificacoes" on public.verificacoes_identidade
  for update using (public.meu_papel() in ('admin', 'admin_principal'));

-- CONTAS BANCÁRIAS
create policy "usuario ve a propria conta bancaria" on public.contas_bancarias
  for select using (usuario_id = auth.uid());

create policy "usuario cadastra a propria conta bancaria" on public.contas_bancarias
  for insert with check (usuario_id = auth.uid());

create policy "usuario edita a propria conta bancaria" on public.contas_bancarias
  for update using (usuario_id = auth.uid());

create policy "admin ve todas as contas bancarias" on public.contas_bancarias
  for select using (public.meu_papel() in ('admin', 'admin_principal'));

-- PONTOS LEDGER (só admin lança pontos; usuário só lê o próprio histórico)
create policy "usuario ve o proprio historico de pontos" on public.pontos_ledger
  for select using (usuario_id = auth.uid());

create policy "admin ve todo o historico de pontos" on public.pontos_ledger
  for select using (public.meu_papel() in ('admin', 'admin_principal'));

create policy "admin lanca pontos" on public.pontos_ledger
  for insert with check (public.meu_papel() in ('admin', 'admin_principal'));

-- SOLICITAÇÕES DE SAQUE
create policy "usuario ve os proprios saques" on public.solicitacoes_saque
  for select using (usuario_id = auth.uid());

create policy "usuario solicita saque" on public.solicitacoes_saque
  for insert with check (usuario_id = auth.uid());

create policy "admin ve todos os saques" on public.solicitacoes_saque
  for select using (public.meu_papel() in ('admin', 'admin_principal'));

create policy "admin atualiza saques" on public.solicitacoes_saque
  for update using (public.meu_papel() in ('admin', 'admin_principal'));

-- AUDIT LOG (só admin lê; qualquer inserção é feita via funções internas)
create policy "admin ve o audit log" on public.audit_log
  for select using (public.meu_papel() in ('admin', 'admin_principal'));

create policy "admin registra no audit log" on public.audit_log
  for insert with check (public.meu_papel() in ('admin', 'admin_principal'));

-- =========================================================
-- FUNÇÕES RPC - operações que precisam ser atômicas
-- (nunca deixar saldo de pontos inconsistente)
-- =========================================================

-- Admin credita pontos a um usuário
create or replace function public.admin_creditar_pontos(
  p_usuario_id uuid,
  p_quantidade integer,
  p_motivo text
)
returns void
language plpgsql
security definer
as $$
begin
  if public.meu_papel() not in ('admin', 'admin_principal') then
    raise exception 'Sem permissão para creditar pontos.';
  end if;

  if p_quantidade <= 0 then
    raise exception 'Quantidade de pontos inválida.';
  end if;

  insert into public.pontos_ledger (usuario_id, tipo, quantidade, motivo, criado_por)
  values (p_usuario_id, 'credito', p_quantidade, p_motivo, auth.uid());

  update public.profiles
  set saldo_pontos = saldo_pontos + p_quantidade, atualizado_em = now()
  where id = p_usuario_id;

  insert into public.audit_log (ator_id, acao, entidade, entidade_id, detalhes)
  values (auth.uid(), 'creditar_pontos', 'profiles', p_usuario_id,
    jsonb_build_object('quantidade', p_quantidade, 'motivo', p_motivo));
end;
$$;

-- Usuário solicita saque: debita o saldo imediatamente (reserva os pontos)
create or replace function public.solicitar_saque(
  p_conta_bancaria_id uuid,
  p_pontos integer
)
returns uuid
language plpgsql
security definer
as $$
declare
  v_saldo integer;
  v_status_verificacao status_verificacao;
  v_valor numeric(10,2);
  v_saque_id uuid;
begin
  select status into v_status_verificacao
  from public.verificacoes_identidade where usuario_id = auth.uid();

  if v_status_verificacao is distinct from 'aprovado' then
    raise exception 'Identidade ainda não verificada e aprovada.';
  end if;

  select saldo_pontos into v_saldo from public.profiles where id = auth.uid();

  if p_pontos <= 0 or p_pontos > v_saldo then
    raise exception 'Saldo de pontos insuficiente.';
  end if;

  v_valor := p_pontos::numeric / 100; -- 100 pontos = R$ 1,00

  update public.profiles
  set saldo_pontos = saldo_pontos - p_pontos, atualizado_em = now()
  where id = auth.uid();

  insert into public.pontos_ledger (usuario_id, tipo, quantidade, motivo, criado_por)
  values (auth.uid(), 'debito', p_pontos, 'Solicitação de saque', auth.uid());

  insert into public.solicitacoes_saque
    (usuario_id, conta_bancaria_id, pontos_debitados, valor_reais, status)
  values (auth.uid(), p_conta_bancaria_id, p_pontos, v_valor, 'pendente')
  returning id into v_saque_id;

  return v_saque_id;
end;
$$;

-- Admin atualiza o status de um saque (aprova, paga ou rejeita)
create or replace function public.admin_atualizar_saque(
  p_saque_id uuid,
  p_novo_status status_saque,
  p_observacao text default null
)
returns void
language plpgsql
security definer
as $$
declare
  v_usuario_id uuid;
  v_pontos integer;
begin
  if public.meu_papel() not in ('admin', 'admin_principal') then
    raise exception 'Sem permissão para atualizar saques.';
  end if;

  select usuario_id, pontos_debitados into v_usuario_id, v_pontos
  from public.solicitacoes_saque where id = p_saque_id;

  update public.solicitacoes_saque
  set status = p_novo_status,
      observacao_admin = coalesce(p_observacao, observacao_admin),
      revisado_por = auth.uid(),
      pago_em = case when p_novo_status = 'pago' then now() else pago_em end,
      atualizado_em = now()
  where id = p_saque_id;

  -- Se for rejeitado, devolve os pontos reservados ao usuário
  if p_novo_status = 'rejeitado' then
    update public.profiles
    set saldo_pontos = saldo_pontos + v_pontos, atualizado_em = now()
    where id = v_usuario_id;

    insert into public.pontos_ledger (usuario_id, tipo, quantidade, motivo, criado_por)
    values (v_usuario_id, 'credito', v_pontos, 'Estorno de saque rejeitado', auth.uid());
  end if;

  insert into public.audit_log (ator_id, acao, entidade, entidade_id, detalhes)
  values (auth.uid(), 'atualizar_saque', 'solicitacoes_saque', p_saque_id,
    jsonb_build_object('novo_status', p_novo_status, 'observacao', p_observacao));
end;
$$;

-- Admin bloqueia/desbloqueia usuário ou muda seu papel
create or replace function public.admin_atualizar_usuario(
  p_usuario_id uuid,
  p_status status_conta default null,
  p_role user_role default null
)
returns void
language plpgsql
security definer
as $$
begin
  if public.meu_papel() not in ('admin', 'admin_principal') then
    raise exception 'Sem permissão para atualizar usuários.';
  end if;

  -- Só o admin_principal pode promover/rebaixar outros admins
  if p_role is not null and public.meu_papel() <> 'admin_principal' then
    raise exception 'Somente o administrador principal pode alterar papéis.';
  end if;

  update public.profiles
  set status = coalesce(p_status, status),
      role = coalesce(p_role, role),
      atualizado_em = now()
  where id = p_usuario_id;

  insert into public.audit_log (ator_id, acao, entidade, entidade_id, detalhes)
  values (auth.uid(), 'atualizar_usuario', 'profiles', p_usuario_id,
    jsonb_build_object('status', p_status, 'role', p_role));
end;
$$;

-- Admin aprova/rejeita verificação de identidade
create or replace function public.admin_atualizar_verificacao(
  p_verificacao_id uuid,
  p_status status_verificacao,
  p_observacao text default null
)
returns void
language plpgsql
security definer
as $$
begin
  if public.meu_papel() not in ('admin', 'admin_principal') then
    raise exception 'Sem permissão para revisar verificações.';
  end if;

  update public.verificacoes_identidade
  set status = p_status,
      observacao_admin = coalesce(p_observacao, observacao_admin),
      revisado_por = auth.uid(),
      atualizado_em = now()
  where id = p_verificacao_id;

  insert into public.audit_log (ator_id, acao, entidade, entidade_id, detalhes)
  values (auth.uid(), 'atualizar_verificacao', 'verificacoes_identidade', p_verificacao_id,
    jsonb_build_object('status', p_status));
end;
$$;

-- =========================================================
-- REALTIME - habilita a sincronização em tempo real nas tabelas
-- que precisam refletir mudanças automaticamente na tela
-- =========================================================
alter publication supabase_realtime add table public.profiles;
alter publication supabase_realtime add table public.pontos_ledger;
alter publication supabase_realtime add table public.solicitacoes_saque;
alter publication supabase_realtime add table public.verificacoes_identidade;
